### Introduction

Python language framework for Robot Process Automation.

### Supported Python Versions

Python 3.4+

### Installation

```sh
$ pip install mozart_framework
```

