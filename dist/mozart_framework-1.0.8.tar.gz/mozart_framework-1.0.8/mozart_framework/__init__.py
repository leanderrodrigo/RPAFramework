
from mozart_framework.DatabaseDriver import DatabaseAutomator
from mozart_framework.EmailDriver import EmailAutomator
from mozart_framework.ExcelDriver import ExcelAutomator
from mozart_framework.FileFolderDriver import FileFolderAutomator
from mozart_framework.JamesDriver import James
from mozart_framework.LogDriver import LogAutomator
from mozart_framework.OcrSpaceDriver import OcrSpace
from mozart_framework.PDFDriver import PDFAutomator
from mozart_framework.QueueItem import QueueItem
from mozart_framework.ScreenshotDriver import ScreenshotAutomator
from mozart_framework.UIDriver import UIAutomator
from mozart_framework.WebDriver import BrowserAutomator


desktop = UIAutomator()
desktop.assignWindowThatContainsNameToObject('Excel')
desktop.waitWindowDesccendantExists('Salvar como' , 'Excel')
#desktop.printAllControlsForCurrentWindow()